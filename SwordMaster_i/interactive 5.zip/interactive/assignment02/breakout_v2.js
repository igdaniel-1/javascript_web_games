// breakout v 2

// javascript file for breakout game

//backgrounds
let backdrop;
let bg1 = 250;
let bg2 = 750;	// file is 500x1000

// variable declarations
let paddle;

// fruits
let melon;
let cherry;
let orange;
let apple;
let lemon;

let fruit;
let fruit_count = 0;


// kirby;
let kirby_left;
let kirby_right;

let message = "Click to Start!";
let start_message = "Click to Start!";
let empty_message = '';

let now_playing = false; 	// keeps track of if the game has been started for mousePressed()
let score = 0;
let total_bounces = 0;

//sounds
let boing;
let chomp;
let loss;

// set paddle starting position
let paddleX = 225;
let paddleY = 530;

// set melon starting position
let fruitX = 225;
let fruitY = 300;

// kirby starting position
let kirbyX = -20;
let kirbyY = -20;

// speed variables
let paddleSPX = 1; 
let fruitSPX = 0;
let fruitSPY = 0;


function preload(){
	backdrop = loadImage("starfield.png");

	//sounds
	boing = loadSound("boing.mp3");
	chomp = loadSound("chomp.mp3");
	loss = loadSound("loss.mp3");

	paddle = loadImage('neon-rectangle.png');
	//fruits
	melon = loadImage('melon.png');
	cherry = loadImage('cherry.png');
	orange = loadImage('orange.png');
	apple = loadImage('apple.png');
	lemon = loadImage('lemon.png');

	// kirby skins
	kirby_left = loadImage('kirby_left.png');
	kirby_right = loadImage('kirby_right.png');

}

function setup() {
  // set the background size of our canvas
  createCanvas(450, 600);

  // background
  background(10, 10, 50);

  // fill color
  noStroke()
  fill(35, 35, 130);

  // 3 borders:
  //top
  rect(0, 0, 450, 30)
  // left
  rect(0, 0, 30, 560)
  // right
  rect(420, 0, 30, 560)
}

function mousePressed(){
	if (now_playing == false){
		fill(255);
  		noStroke();
		message = empty_message;

		// place kirby
		kirbyX = random(80, 350);
		kirbyY = random(80, 350);

		// create a pos and neg pool for both X and Y
		// randomly pick pos/neg for X/Y

		random_negative = random(-5, -2);
		random_positive = random(2, 5);

		pos_neg_X = random(1,3);
		pos_neg_Y = random(1,3);

		if (pos_neg_X < 2){
			fruitSPX = random_negative;
		}
		else{
			fruitSPX = random_positive;
		}

		if (pos_neg_Y < 2){
			fruitSPY = random_negative;
		}
		else{
			fruitSPY = random_positive;
		}
		now_playing = true;
	}
	
}

function draw(){
	// to reset background after sprite movement
	background(10, 10, 50);	
	image(backdrop, 250, bg1);
	image(backdrop, 250, bg2);

	//move background
	bg1 -= 2;
  	bg2 -= 2;

  	// shuffle background back to top
  	if (bg1 <= 50) {
	    // move it back to the right of p2
	    bg1 = bg2 + 500;
	    console.log("cycle p1");
	}
	if (bg2 <= 50) {
	    // move it back to the right of p1
	    bg2 = bg1 + 500;
	    console.log("cycle p2");
	}

	// reset bumpers
	// 3 borders:
	noStroke()
  	fill(35, 35, 130);
	//top
    rect(0, 0, 450, 30);
	// left
	rect(0, 0, 30, 560);
	// right
	rect(420, 0, 30, 560);

	// text info will go here
	fill(255);
  	noStroke();
	text(message, 190, 250);

	text("Score: " + score, 100, 20);
	text("Total Bounces: " + total_bounces, 240, 20);

	// insert paddle
	imageMode(CENTER);
	image(paddle, paddleX, paddleY, 160, 80);

	// insert fruit
	let fruits = [melon, cherry, orange, apple, lemon];
	fruit = fruits[fruit_count];
	image(fruit, fruitX, fruitY, 25, 25);

	// choose kirby skin
	if (kirbyX < 220){
		image(kirby_left, kirbyX, kirbyY, 70, 70);
	}
	else{
		image(kirby_right, kirbyX, kirbyY, 70, 70);
	}



	// move the paddle
	if (keyIsDown(65)){
		paddleX -= 3;
	}
	if (keyIsDown(68)){
		paddleX += 3;	
	}

	// paddle boundaries
	if (paddleX < 90){
		paddleX = 90;
	}
	if (paddleX > 350){
		paddleX = 350;
	}

	// move the ball
	fruitX += fruitSPX;
  	fruitY += fruitSPY;

  	// check if ball hit the walls
  	//left side
  	if (fruitX < 45){
  		fruitX = 45;
  		total_bounces += 1;
  		fruitSPX *= -1;
  		// bounce sound
  		boing.play();
  	}
  	//right side
  	if (fruitX > 415){	// this may need to be moved left 20
  		fruitX = 415;
  		total_bounces += 1;
  		fruitSPX *= -1;
  		// bounce sound
  		boing.play();
  	}
  	// top side
  	if (fruitY < 45){
  		fruitY = 45;
  		total_bounces += 1;
  		fruitSPY *= -1;
  		// bounce sound
  		boing.play();
  	}

  	// bottom out of bounds
  	if (fruitY > 620){
  		// loss sound
  		loss.play();

  		// reset fruit
  		fruitX = 225;
		fruitY = 300;
  		fruitSPX = 0;
		fruitSPY = 0;

		// reset paddle
		paddleX = 225;
		paddleY = 530;

		// change kirby position
		kirbyX = -20;
		kirbyY = -20;

		now_playing = false;
		fill(255);
  		noStroke();
		message = start_message;
		score = 0;
		total_bounces = 0;
		fruit_count = 0;
  	}



  	// check if ball hits the paddle
  	let distCenter = dist(paddleX, paddleY, fruitX, fruitY);
  	let distLeft = dist(paddleX+40, paddleY, fruitX, fruitY);
  	let distRight = dist(paddleX-40, paddleY, fruitX, fruitY);
  	fill(255);
  	noStroke();

  	// only check collisions while over Y=550
  	if (fruitY > 550 && fruitY < 565){
  		// text("below", 100, 250);
  		if (distCenter < 30) {
		    // text("Collision!", 200, 260);
		    fruitSPY *= -2;
		    fruitSPX *= 0.5;
		    // bounce sound
  			boing.play();
		}

		else if (distLeft < 40) {
			// text("Left Collision!", 200, 260);
		    fruitSPY *= -1;
		    fruitSPX *= -2;
		    // bounce sound
  			boing.play();
		}

		else if (distRight < 40) {
			// text("Right Collision!", 200, 260);
		    fruitSPY *= -1;
		    fruitSPX *= -2;
		    // bounce sound
  			boing.play();
		}
		// speed limit high
		if (fruitSPX > 5){
			fruitSPX = 5;
		}
		if (fruitSPX < -5){
			fruitSPX = -5;
		}
		if (fruitSPY > 5){
			fruitSPY = 5;
		}
		if (fruitSPY < -5){
			fruitSPY = -5;
		}
		// speed limit low
		if (fruitSPX < 2 && fruitSPX > 0){
			fruitSPX = 2;
		}
		if (fruitSPX > -2 && fruitSPX < 0){
			fruitSPX = -2;
		}
		if (fruitSPY < 2 && fruitSPY > 0){
			fruitSPY = 2;
		}
		if (fruitSPY > -2 && fruitSPY < 0){
			fruitSPY = -2;
		}
		
  	}

  	// check if melon collides with kirby
  	let distKirby = dist(kirbyX, kirbyY, fruitX, fruitY);
  	if (distKirby < 40){
  		score += 1;
  		fruit_count += 1;

  		if (fruit_count > 4){
  			fruit_count = 0;
  		}
  		// chomp sound
  		chomp.play();
  		// move kirby
  		kirbyX = random(80, 350);
		kirbyY = random(80, 350);

  	}
}















// end