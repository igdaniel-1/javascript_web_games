// new js file


function setup() {
  // set the background size of our canvas
  createCanvas(400, 400);

  // red background
  background(255, 0, 0);

  // set all content drawn from this point forward
  // so that it uses "yellow" (0 = black, 255 = white)
  fill(255, 255, 255);

  // write some text at position 100,100
  text("Pika Pika!", 170,60);

  //remove outline
  noStroke()

  // all YELLOW shapes
  fill(255, 204, 0);
  // head
  ellipse(200,225, 125, 105);
  // left ear
  triangle(140, 210, 180, 175, 100, 120)
  // right ear
  triangle(260, 210, 220, 175, 300, 120)

  // all BLACK shapes (ear tips)
  fill(0, 0, 0);
  // left ear tip
  triangle(120, 165, 130, 140, 100, 120)
  // right ear tip
  triangle(280, 165, 270, 140, 300, 120)


  // all RED shapes (cheeks)
  fill(255, 0, 0);
  // left cheek
  ellipse(163, 245, 34, 31);
  // right cheek
  ellipse(237, 245, 34, 31);




}




